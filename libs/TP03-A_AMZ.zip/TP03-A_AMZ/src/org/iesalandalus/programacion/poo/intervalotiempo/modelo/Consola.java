package org.iesalandalus.programacion.poo.intervalotiempo.modelo;

import org.iesalandalus.programacion.utilidades.Entrada;

public class Consola {
    private Consola(){

    }
    public Tiempo leeTiempoHora() {
        int hora = 0;
        System.out.println("Dime la hora: ");
        hora = Entrada.entero();
        return new Tiempo(hora);
    }
    private int leerHora(){
    }
    public Tiempo leerTiempoHoraMinuto(){
        int hora = 0;
        int minuto = 0;
        System.out.println("Dime la hora: ");
        hora = Entrada.entero();
        System.out.println("Dime el minuto: ");
        return new Tiempo(minuto);
    }
    private int leerMinuto(){

    }
    private Tiempo leerTiempoCompleto(){

    }
    private int leeSegudno(){

    }
    private IntervaloTiempo leerIntervalo(){

    }
}
