package org.iesalandalus.programacion.poo.intervalotiempo.modelo;

import java.beans.IntrospectionException;
import java.util.Objects;

public record IntervaloTiempo(Tiempo inicio, Tiempo fin) {
    public IntervaloTiempo {
        if (!fin.mayorQue(inicio)) {
            throw new IllegalArgumentException("El tiempo de fin debe ser posterior al tiempo de inicio.");
        }
    }

    public Tiempo getDuracion() {
        return fin.restar(inicio);
    }

    public IntervaloTiempo ampliarPorAbajo(Tiempo cantidad) {
        Tiempo nuevoInicio = inicio.restar(cantidad);
        return new IntervaloTiempo(nuevoInicio, fin);
    }

    public IntervaloTiempo ampliarPorArriba(Tiempo cantidad) {
        Tiempo nuevoFin = fin.sumar(cantidad);
        return new IntervaloTiempo(inicio, nuevoFin);
    }

    public IntervaloTiempo reducirPorAbajo(Tiempo cantidad) {
        Tiempo nuevoInicio = inicio.sumar(cantidad);
        return new IntervaloTiempo(nuevoInicio, fin);
    }

    public IntervaloTiempo reducirPorArriba(Tiempo cantidad) {
        Tiempo nuevoFin = fin.restar(cantidad);
        return new IntervaloTiempo(inicio, nuevoFin);
    }

    public boolean menorQue(IntervaloTiempo intervaloTiempo) {
        return this.getDuracion().menorQue(intervaloTiempo.getDuracion());
    }

    public boolean mayorQue(IntervaloTiempo intervaloTiempo) {
        return intervaloTiempo.getDuracion().menorQue(this.getDuracion());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        IntervaloTiempo that = (IntervaloTiempo) o;
        return Objects.equals(getDuracion(), that.inicio);
    }

    @Override
    public int hashCode() {
        return Objects.hash(inicio, fin);
    }

    @Override
    public String toString() {
        return "[" + inicio + " - " + fin + "]";
    }
}